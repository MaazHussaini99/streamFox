/*import java.util.*;
public class CaesarCipherProgram {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println(" Input the ciphertext message : ");
        String ciphertext = sc.nextLine();
        System.out.println(" Enter the shift value : ");
        int shift = sc.nextInt();
        String decryptMessage = "";
        for(int i=0; i < ciphertext.length();i++)

        {
            // Shift one character at a time
            char alphabet = ciphertext.charAt(i);
            // if alphabet lies between a and z
            if(alphabet >= 'a' && alphabet <= 'z')
            {
                // shift alphabet
                alphabet = (char) (alphabet - shift);

                // shift alphabet lesser than 'a'
                if(alphabet < 'a') {
                    //reshift to starting position
                    alphabet = (char) (alphabet-'a'+'z'+1);
                }
                decryptMessage = decryptMessage + alphabet;
            }
            // if alphabet lies between A and Z
            else if(alphabet >= 'A' && alphabet <= 'Z')
            {
                // shift alphabet
                alphabet = (char) (alphabet - shift);

                //shift alphabet lesser than 'A'
                if (alphabet < 'A') {
                    // reshift to starting position
                    alphabet = (char) (alphabet-'A'+'Z'+1);
                }
                decryptMessage = decryptMessage + alphabet;
            }
            else
            {
                decryptMessage = decryptMessage + alphabet;
            }
        }

   //     NmwgjDijsinjnmwrnwxttkyNsStymzsiYwzgxfqgjDljxyfsijsXflyBfxnmwBtmqnsijzyxhmjsQfsijsatszsxwjwZsyjwsjmrzslmtkkyNhmBzsxhmyjxjmwijwRjsljEzgjmfljsGjxtsijwxBjnqxnjqjgyzsiqjgjsqfxxyInjUktxyjsxnsiinjGwjyjwfzkljxhmqfljsZsiojijwrfssjwBfwyjyxnhmjnsKjxyXnjxnyEjsxhmtsrnymtmjsFzljsgwfzsjsLjqfxxjsifzsirthmyjsljwsjwxyfzsjsNhmBjnxxBnjrfsijsLjnxyijxatqpxAjwxtmsyIthmxtAjwqjljsgnsnhmsnjljBjxjseBfwxnsixnjfsifxGjxyjsnhmyljBtmsyFqqjnsxnjmfgjsxhmwjhpqnhmAnjqljqjxjsbnjrfhmjsBnwxifxxfqqjxkwnxhmzsisjzZsirnyGjijzyzslfzhmljkfqqnlxjDIjsskwjDqnhmrflnhmljwsinjRjsljxmjsbjssxnhmijwXywtrsfhmzsxwjwGzijiwfslyZsirnyljBfqynlBnjijwmtqyjsbjmjsXnhmizwhminjjsljLsfijsuktwyjEBfslyGjDmjqqjrYfljxhmtsAtwanjwjsRnyXytxxjsxnhmgnxfsinjPfxxjknhmyZsiBnjnsMzsljwxstymzrGwtyfsGjhpjwymzwjsZrjnsGnqqjyxnhmkfxyinjMfqxjgwnhmyInjxxbzsijwBnwpyfzkxtAjwxhmnjisjQjzyjIjwInhmyjwszwrjnsKwjzsitymzjxmjzyjTxuwnhmrnwsnhmyAtsojsjwgzsyjsRjsljGjDijwjsFsgqnhpzsxijwLjnxyjsykqnjmyajwmzqqjrnwifxBtljsijLjiwfsljIfxBnijwbnqqjszsxEzrXywzijqEnjmySjnskzmwjrnhmEzwxynqqjsMnrrjqxjsljbtszwijrInhmyjwwjnsjKwjzijgqzmybtQnjgzsiKwjzsixhmfkyzsxwjxMjwEjsxXjljsRnyLtyyjwmfsijwxhmfkkjszsijwukqjljsFhmBfxnsynjkjwGwzxyzsxifjsyxuwzsljsbfxxnhminjQnuujxhmzhmyjwsAtwljqfqqyRnxxwfymjsojyEyzsiojyEyAnjqqjnhmyljqzsljsajwxhmqnslyijxBnqijsFzljsgqnhpxLjBfqyTkyBjssjxjwxyizwhmOfmwjizwhmljiwzsljsJwxhmjnsyjxnsAtqqjsijyjwLjxyfqybfxlqfsEynxykzwijsFzljsgqnhpljgtwjsIfxFjhmyjgqjngyijwSfhmBjqyzsAjwqtwjs
        System.out.println(" decrypt message : " + decryptMessage);
    }
}*/


import java.util.Scanner;

public class CaesarCipherMain {
    public static final String alph = "abcdefghijklmnopqrstuvwxyz";
    // static because all other functions are static, and we can't reference from a
    // non-static

    public static String encoding(String plainT, int shift) {
        plainT = plainT.toLowerCase();
        // converting the text to lowercase
        String cipherT = "";
        // initializing empty string to add alphabets iteratively
        for (int i = 0; i < plainT.length(); i++) {
            int mappingV = alph.indexOf(plainT.charAt(i));
            // value of each alphabet in integers like for A=0, B=1 ...
            int enVal = (shift + mappingV) % 26;
            char Val = alph.charAt(enVal); // the character to be replaced
            cipherT = cipherT + Val; // adding to ciphertext
        }
        return cipherT;
    }

    // following same algorithm but in reverse way, plaintext becomes
    // ciphertext and vice versa
    public static String decoding(String cipherT, int shift) { //
        cipherT = cipherT.toLowerCase();//g
        // converting the text to lowercase
        String plainT = "";//empty string to store plain text
        for (int i = 0; i < cipherT.length(); i++) {
            int mappingV = alph.indexOf(cipherT.charAt(i));//    alph.indexof(charAT 6 = g)
            //mappingV=6
            int deVal = (mappingV - shift) % 26;// 6 -21 % 26
            //-15
            if (deVal < 0) // to handle the negative values
            {
                deVal = alph.length() + deVal;//26 + -15 =11
            }
            char Val = alph.charAt(deVal); // the character to be replaced
            //char at 11
            if (alph.indexOf(deVal)==11){
                System.out.println("flag"+alph.charAt(Val));
            }
            plainT = plainT + Val; // adding to plaintext
        }
        return plainT;
        //B
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the text message to be encrypted ");
     //GDrjfsxtkymjjCyjwsfqxjsxjfuwtujwyDtkymjrnsiBjwjuwjxjsyyttzwxjqAjxtgojhyxfxBnymtzyzxfsiymjxjfqqnsxufhjMjwjnsfqtsjfwjymjnwxmfujinrjsxntsxfsiwjqfyntsxytjfhmtymjwijyjwrnsjitwijyjwrnsfgqjYmjnsyjwsfqxjsxjgDrjfsxtkBmnhmymjrnsihtsyjruqfyjxnyxjqktwnyxnsyjwsfqxyfyjlnAjxnsijjistnsyznyntstkymjxtzqfxfstgojhyDjyymjwjnxsjAjwymjqjxxfijyjwrnsfyjktwrzsijwBmnhmfqtsjymjhtsyjruqfyntstktzwnsyjwsfqxyfyjnxutxxngqjxtymfyfqqBmnhmwjqfyjxytymjnsBfwiijyjwrnsfyntsxtkymjrnsinxwjuwjxjsyjinswjqfyntsxtkynrjTkynrjBjhfsstymfAjfsDjCyjwsfqnsyznyntsfsDrtwjymfsBjhfsmfAjfsnsyjwsfqnsyznyntstkxufhjbmfyymjsfwjynrjfsixufhjFwjymjDwjfqjCnxyjshjxTwfwjymjDrjwjqDwjqfyntsxtwijyjwrnsfyntsxtkymnslxxzhmmtBjAjwfxBtzqijvzfqqDgjqtslytymjxjymnslxnsymjrxjqAjxymtzlmymjDxmtzqisjAjwgjhtrjtgojhyxtknsyznyntstwfwjymjDxzhmfxgjqtsltsqDytymjktwrtknsyznyntsfsihtsxjvzjsyqDytymjxzgojhynAjhtsxynyzyntstkymjrnsiBnymtzyBmnhmymjxjuwjinhfyjxtkynrjfsixufhjhtzqistygjfyyfhmjiytfsDtgojhyNstwijwytgjhtrjnsktwrjitsymjxjutnsyxBjxmfqqknwxylnAjfsjCutxnyntstkymjhtshjuyntstkxufhjGDjCutxnyntsNrjfsymjhqjfwymtzlmstyijyfnqjiwjuwjxjsyfyntstkymfyBmnhmgjqtslxytfhtshjuyntsfsifsjCutxnyntsnxrjyfumDxnhfqBmjsnyhtsyfnsxymfyBmnhmwjuwjxjsyxymjhtshjuyntsfxlnAjsuwntwn

        String msg = new String();
        msg = scan.next();
        //System.out.println(" Encrypted Text : " + encoding(msg, 4));
        System.out.print(" Decryptd Text : ");
        System.out.print(decoding(msg, -21));
        scan.close();
        System.out.println("\n");

        System.out.println(alph.length());
        for (int i=0; i<alph.length();i++){

            char c=alph.charAt(i);
            System.out.println( alph.charAt(i)+" "+alph.indexOf(c));

        }


    }
}