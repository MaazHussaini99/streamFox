/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.streamfox;

/**
 *
 * @author jonat
 */
public class VidObj {
    
    String id;
    String title;
    String channel;
    public VidObj(String id, String title, String channel){
        this.id = id;
        this.title = title;
        this.channel = channel;
    }
    /*
    public VidObj[] help = {new VidObj("YLt73w6criQ", "I Paid A Real Assassin To Try To Kill Me", "MrBeast"),
    new VidObj("dT6taoucBX4", "SCREAMS SCREAMS and MORE SCREAMS [Fears To Fathom: Norwood Hitchhike]", "CoryxKenshin"),
    new VidObj("_F6YBwIPzmk", "Star Wars Jedi: Survivor - Official Story Trailer", "EA Star Wars"),
    new VidObj("_F6YBwIPzmk", "Star Wars Jedi: Survivor - Official Story Trailer", "EA Star Wars"),
    new VidObj("LtwaDBjNop0", "Resumen de FC Barcelona vs Real Madrid (2-1)", "LaLiga Santander"),
    new VidObj("DOWDNBu9DkU", "Amazing Invention- This Drone Will Change Everything", "Mark Rober"),
    new VidObj("scTOJJbecGw", "Fooling my Friend with the LOUDEST SOUND in Minecraft", "Doni Bobes"),
    new VidObj("EDnwWcFpObo", "NMIXX 'Love Me Like This' M/V", "JYP Entertainment"),
    new VidObj("bEKmOVP-SOI", "Can You ACTUALLY Win Money on Gameshows?", "Jaiden Animations"),
    new VidObj("moIuur9GUws", "World's Brightest Flashlight | OT38", "Dude Perfect"),
    new VidObj("q3FXUUV3hWA", "Different Childhood Sleepovers (pt.5) | Ep.1 Dtay Known", "Dtay Known"),
    new VidObj("5RNrCRjZO0M", "I Played Diablo 4 Beta.. My HONEST Thoughts", "Asmongold TV "),
    new VidObj("S9EnUSSU7HI", "I Trapped 25 TikTokers In A Box", "Airrack"),
    new VidObj("clJyTJ3vvh4", "Momoshiki vs Kawaki | Boruto: Naruto Next Generations", "Crunchyroll Collection"),
    new VidObj("myNFxrTMczA", "Best Watercolor Art Wins $5,000!", "ZHC Crafts"),
    new VidObj("PZM6j8bKnks", "Ben Affleck and Matt Damon on 'Air'", "CBS Sunday Morning")
    };*/
       
}
